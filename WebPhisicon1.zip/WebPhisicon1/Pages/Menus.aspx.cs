﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebPhisicon.Models;
using WebPhisicon.Models.Repository;

namespace WebPhisicon.Pages
{
    public partial class Menus : System.Web.UI.Page
    {
        private CourseModulesRepository repository = new CourseModulesRepository();
//        static int iMenuItem;
        static string cAllfiltr = "";
        static string cGrade = "";
        static string cSubject = "";
        static string cGenre = "";
        protected IEnumerable<vCourseModules> GetCoursesModules()
        {
            return repository.GetAllCourses(cAllfiltr);
        }
 
        [System.Web.Services.WebMethod]
        public static string GetCourse(string param1) //принимающий, обрабатывающий и отправляющий обратно данные метод
        {
            Models.Course course = new Course();
            string c1 = course.GetCourseInt(param1);
//            c1 = "{'name':'Vano','age':37}";
            return c1;
         }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                string category;
                string module;
                int i = 0;
                int j = 0;
                int iOrder = 0;
                string s1 = new string('\u00A0', 1);
                MenuItem itemCategory0 = null;
                foreach (vCourseModules course in GetCoursesModules())
                {
                    category = course.cTitle;
                    iOrder = course.Order;
                    if (iOrder == 0)
                    {
                        i++;
                        MenuItem itemCategory = new MenuItem(s1 + category, i.ToString());
                        itemCategory.Value = i.ToString();
                        Menu1.Items.Add(itemCategory);
                        itemCategory0 = itemCategory;
                        j = 0;
                    }
                    j++;
                    module = course.MTitle;
                    MenuItem itemProduct = new MenuItem(s1 + module, j.ToString());
                    itemCategory0.ChildItems.Add(itemProduct);
                }
//                Menu1.Items[iMenuItem].Selected = true;
                TextBoxGrade.Text = cGrade;
                TextBoxSubject.Text = cSubject;
                TextBoxGenre.Text = cGenre;
            }
        }

        protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
        {

        }
        protected string GetFiltrString()
        {
            string sFiltr = "";
            if (TextBoxSubject.Text.Length > 0)
            {
                if (sFiltr.Length > 0)
                    sFiltr += " AND ";
                sFiltr += " ([Subject]='" + TextBoxSubject.Text + "')";
            }    
            if (TextBoxGenre.Text.Length > 0)
            {
                if (sFiltr.Length > 0)
                    sFiltr += " AND ";
                sFiltr += " ([Genre]='" + TextBoxGenre.Text + "')";
            }
            if (TextBoxGrade.Text.Length > 0)
            {
                if (sFiltr.Length > 0)
                    sFiltr += " AND ";
                sFiltr += " ([Grade]='" + TextBoxGrade.Text + "')";
            }
            if (sFiltr.Length == 0)
                return sFiltr;
            else
                return (" WHERE " + sFiltr);
        }
        protected void GetNewFiltr(object sender, ImageClickEventArgs e)
        {
            cAllfiltr = GetFiltrString();
            cGrade = TextBoxGrade.Text;
            cSubject = TextBoxSubject.Text;
            cGenre = TextBoxGenre.Text;
            Response.Redirect(Request.RawUrl);
        }
    }
}