﻿using Dapper;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System;

namespace WebPhisicon.Models.Repository
{
    public interface ICourseModulesRepository
    {
        IEnumerable<vCourseModules> GetAllCourses(string cFiltr);
    }

    public class CourseModulesRepository : ICourseModulesRepository
    {
        private readonly string _connectionString = ConfigurationManager.ConnectionStrings["DpConnection"].ConnectionString;
        public IEnumerable<vCourseModules> GetAllCourses(string cFiltr)
        {
            using (IDbConnection db = new SqlConnection(_connectionString))
            {
                string cSql = "SELECT DISTINCT cTitle, [Num] + ' ' + [Title] AS MTitle, [Order]";
                cSql = cSql + "FROM [dbo].[vCourseModules] ";
                cSql = cSql + cFiltr + " ORDER BY cTitle, [Order]";
                return db.Query<vCourseModules>(cSql);
            }
        }
    }
}

