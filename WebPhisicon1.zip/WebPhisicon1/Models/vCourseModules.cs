﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebPhisicon.Models
{
    public class vCourseModules
    { 
        public string cTitle { get; set; }
        public string MTitle { get; set; }
         public int Order { get; set; }     
    }
}