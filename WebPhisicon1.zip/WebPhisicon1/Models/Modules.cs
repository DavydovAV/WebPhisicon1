﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebPhisicon.Models
{
    public class Module
    {
        public int Id { get; set; }
        public int CoursesId { get; set; }
        public string Title { get; set; }
        public int Order { get; set; }
        public int Href { get; set; }
        public string Category { get; set; }
        public int ParentId { get; set; }
        public string ExternalId { get; set; }
        public string ContentType { get; set; }
        public string Num { get; set; }
    }
}