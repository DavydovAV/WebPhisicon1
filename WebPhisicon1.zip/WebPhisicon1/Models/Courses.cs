﻿using Dapper;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Unicode;

namespace WebPhisicon.Models
{
    public class Course
    {
        private readonly string _connectionString = ConfigurationManager.ConnectionStrings["DpConnection"].ConnectionString;

        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public string ExternalId { get; set; }
        public string Hash { get; set; }
        public string Subject { get; set; }
        public string Grade { get; set; }
        public string Genre { get; set; }

        public Course Get(int id)
        {
            using (IDbConnection db = new SqlConnection(_connectionString))
            {
                return db.Query<Course>("SELECT * FROM Courses WHERE Id = @id", new { id }).FirstOrDefault();
            }
        }
        public string GetCourseInt(string param1)
        {
            int iNom;
            var options = new JsonSerializerOptions()
            {
                AllowTrailingCommas = true,
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                Encoder = JavaScriptEncoder.Create(UnicodeRanges.All),
                WriteIndented = true
            };
            if (param1 == "")
                return "";
            else
            {
                try
                {
                    iNom = int.Parse(param1);
                }
                catch (ArgumentException)
                {
                    return "";
                }
            }
            Course course = Get(iNom);
            string json = JsonSerializer.Serialize<Course>(course, options);
            return json;
        }
    }
}